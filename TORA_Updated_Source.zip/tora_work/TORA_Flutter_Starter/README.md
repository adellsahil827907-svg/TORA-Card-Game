# TORA Flutter Starter

TORA card game prototype with a functional 52-card deck shuffle and 13-card dealing to each of four players.

## Current implemented foundation
- Creates a standard 52-card deck (2 through Ace in four suits).
- Shuffles the deck randomly at the start of a round.
- Deals 13 cards to each of the four configured players.
- Shows each player's remaining card count.
- Shows the active player's hand and allows selecting/playing a card to advance the turn.
- Shuffle icon starts a fresh round.

## Build
Run `flutter pub get` then `flutter build apk --release`.

This is still an early prototype. Full TORA trick-taking rules, penalty scoring, Takol, multiplayer, and final Play Store readiness are not yet implemented.
