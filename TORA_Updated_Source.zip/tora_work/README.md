# TORA Card Game

Flutter prototype with editable player names, a four-seat center table, drag-and-drop card play for Sahil (seat 1), and automatic random card play for the other three seats.

Important: this is a playable interaction prototype, not the final TORA rules engine. The exact trick-taking rules, scoring, and the “no cards left / 30 points” rule must be specified and validated before they can be implemented correctly. Computer opponents currently play a random card.

## Build
`flutter pub get`
`flutter build apk --release`
