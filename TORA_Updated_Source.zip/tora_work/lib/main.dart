import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const ToraApp());

const gold = Color(0xFFD6A638);
const dark = Color(0xFF090909);
const panel = Color(0xFF17130B);
const felt = Color(0xFF123B2B);

class ToraApp extends StatelessWidget {
  const ToraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'TORA',
    theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: dark, colorScheme: const ColorScheme.dark(primary: gold, secondary: gold, surface: panel)),
    home: const ToraTablePage(),
  );
}

class ToraTablePage extends StatefulWidget {
  const ToraTablePage({super.key});
  @override
  State<ToraTablePage> createState() => _ToraTablePageState();
}

class _ToraTablePageState extends State<ToraTablePage> {
  static const ranks = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
  static const suits = ['♠','♥','♦','♣'];
  final random = Random();
  final List<String> players = ['Sahil','Player 2','Player 3','Player 4'];
  final List<List<String>> hands = List.generate(4, (_) => <String>[]);
  final List<List<String>> played = List.generate(4, (_) => <String>[]);
  int turn = 0;
  int round = 0;
  bool aiBusy = false;
  bool gameOver = false;
  String message = 'Drag one of your cards to the center of the table.';
  int teamOneScore = 0;
  int teamTwoScore = 0;

  @override
  void initState() { super.initState(); _deal(); }

  void _deal() {
    final deck = [for (final s in suits) for (final r in ranks) '$r$s']..shuffle(random);
    setState(() {
      for (var i=0;i<4;i++) {
        hands[i]..clear()..addAll(deck.sublist(i*13,(i+1)*13));
        hands[i].sort((a,b) {
          final sa=suits.indexOf(a.substring(a.length-1)), sb=suits.indexOf(b.substring(b.length-1));
          if(sa!=sb) return sa.compareTo(sb);
          return ranks.indexOf(a.substring(0,a.length-1)).compareTo(ranks.indexOf(b.substring(0,b.length-1)));
        });
        played[i].clear();
      }
      turn=0; aiBusy=false; gameOver=false; message='Your turn — drag a card to the center.'; round++;
    });
  }

  void _play(int seat, String card) {
    if (gameOver || aiBusy || turn != seat || !hands[seat].contains(card)) return;
    setState(() {
      hands[seat].remove(card);
      played[seat].add(card);
      message = '${players[seat]} played $card';
      if (hands.every((h)=>h.isEmpty)) {
        gameOver=true;
        message='Round complete. Start a new round to deal again.';
      } else {
        turn=(turn+1)%4;
      }
    });
    if (!gameOver && turn != 0) _runComputerTurn();
  }

  Future<void> _runComputerTurn() async {
    if (aiBusy || gameOver || turn==0) return;
    aiBusy=true;
    setState(() { message='${players[turn]} is choosing a card…'; });
    await Future.delayed(const Duration(milliseconds: 850));
    if (!mounted || gameOver) return;
    final seat=turn;
    if (hands[seat].isNotEmpty) {
      final card=hands[seat][random.nextInt(hands[seat].length)];
      aiBusy=false;
      _play(seat,card);
    } else {
      aiBusy=false;
    }
  }

  Future<void> _editNames() async {
    final controllers=List.generate(4,(i)=>TextEditingController(text:players[i]));
    await showDialog<void>(context:context,builder:(ctx)=>AlertDialog(
      backgroundColor:panel,
      title:const Text('Player names',style:TextStyle(color:gold)),
      content:Column(mainAxisSize:MainAxisSize.min,children:List.generate(4,(i)=>Padding(
        padding:const EdgeInsets.only(bottom:8),child:TextField(controller:controllers[i],decoration:InputDecoration(labelText:'Player ${i+1}',border:const OutlineInputBorder(),isDense:true)),
      ))),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){
        setState(() { for(var i=0;i<4;i++){ final n=controllers[i].text.trim(); if(n.isNotEmpty) players[i]=n; } });
        Navigator.pop(ctx);
      },child:const Text('Save'))],
    ));
    for(final c in controllers){c.dispose();}
  }

  Widget _card(String value,{double width=48,double height=66,bool small=false}) {
    final red=value.contains('♥')||value.contains('♦');
    return Container(width:width,height:height,decoration:BoxDecoration(color:const Color(0xFFF7F0DF),borderRadius:BorderRadius.circular(7),border:Border.all(color:gold,width:1.2),boxShadow:const [BoxShadow(color:Colors.black54,blurRadius:4,offset:Offset(1,2))]),child:Center(child:Text(value,textAlign:TextAlign.center,style:TextStyle(color:red?Colors.red.shade800:Colors.black,fontSize:small?12:17,fontWeight:FontWeight.w900))));
  }

  Widget _playedAt(int seat) {
    final cards=played[seat];
    if(cards.isEmpty) return const SizedBox(width:54,height:70);
    final visible=cards.length>3?cards.sublist(cards.length-3):cards;
    return SizedBox(width:58,height:76,child:Stack(alignment:Alignment.center,children:[for(var i=0;i<visible.length;i++)Transform.translate(offset:Offset((i-(visible.length-1)/2)*8,0),child:_card(visible[i],width:43,height:61,small:true))]));
  }

  Widget _seatLabel(int seat) => Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:dark.withOpacity(.92),borderRadius:BorderRadius.circular(10),border:Border.all(color:turn==seat?gold:Colors.white24,width:turn==seat?2:1)),child:Column(mainAxisSize:MainAxisSize.min,children:[Text(players[seat],style:TextStyle(color:turn==seat?gold:Colors.white,fontWeight:FontWeight.bold,fontSize:11)),Text('${hands[seat].length} cards',style:const TextStyle(color:Colors.white70,fontSize:9))]));

  Widget _table() => DragTarget<String>(
    onWillAcceptWithDetails:(d)=>turn==0&&!aiBusy&&!gameOver&&hands[0].contains(d.data),
    onAcceptWithDetails:(d)=>_play(0,d.data),
    builder:(context,candidates,rejects)=>AnimatedContainer(duration:const Duration(milliseconds:180),margin:const EdgeInsets.symmetric(horizontal:10,vertical:4),decoration:BoxDecoration(color:felt,borderRadius:BorderRadius.circular(24),border:Border.all(color:candidates.isNotEmpty?Colors.white:gold,width:candidates.isNotEmpty?4:2),boxShadow:const [BoxShadow(color:Color(0x553D2B08),blurRadius:18)]),child:Stack(children:[
      const Center(child:Text('TORA TABLE',style:TextStyle(color:Colors.white24,fontWeight:FontWeight.w900,letterSpacing:3,fontSize:18))),
      Align(alignment:Alignment.topCenter,child:Padding(padding:const EdgeInsets.only(top:9),child:Column(mainAxisSize:MainAxisSize.min,children:[_seatLabel(2),_playedAt(2)]))),
      Align(alignment:Alignment.bottomCenter,child:Padding(padding:const EdgeInsets.only(bottom:9),child:Column(mainAxisSize:MainAxisSize.min,children:[_playedAt(0),_seatLabel(0)]))),
      Align(alignment:Alignment.centerLeft,child:Padding(padding:const EdgeInsets.only(left:5),child:RotatedBox(quarterTurns:1,child:Column(mainAxisSize:MainAxisSize.min,children:[_seatLabel(1),_playedAt(1)])))),
      Align(alignment:Alignment.centerRight,child:Padding(padding:const EdgeInsets.only(right:5),child:RotatedBox(quarterTurns:3,child:Column(mainAxisSize:MainAxisSize.min,children:[_seatLabel(3),_playedAt(3)])))),
      Center(child:Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:6),decoration:BoxDecoration(color:dark.withOpacity(.82),border:Border.all(color:gold.withOpacity(.7)),borderRadius:BorderRadius.circular(10)),child:Text(candidates.isNotEmpty?'Release to play':message, textAlign:TextAlign.center,style:const TextStyle(color:gold,fontSize:10,fontWeight:FontWeight.bold)))),
    ])),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar:AppBar(backgroundColor:dark,foregroundColor:gold,centerTitle:true,title:const Text('👑 TORA',style:TextStyle(color:gold,fontWeight:FontWeight.w900,letterSpacing:3)),actions:[IconButton(tooltip:'Player names',onPressed:_editNames,icon:const Icon(Icons.people_alt_outlined)),IconButton(tooltip:'New round',onPressed:_deal,icon:const Icon(Icons.shuffle))]),
    body:SafeArea(child:Column(children:[
      Padding(padding:const EdgeInsets.symmetric(horizontal:12,vertical:5),child:Row(children:[Expanded(child:_scoreBox('${players[0]} + ${players[2]}',teamOneScore)),const SizedBox(width:8),Expanded(child:_scoreBox('${players[1]} + ${players[3]}',teamTwoScore))])),
      Expanded(child:_table()),
      Padding(padding:const EdgeInsets.fromLTRB(12,5,12,0),child:Row(children:[Expanded(child:Text('${players[0]} — Your hand',style:const TextStyle(color:gold,fontWeight:FontWeight.bold))),Text('${hands[0].length} cards left',style:const TextStyle(color:Colors.white70,fontSize:11))])),
      SizedBox(height:112,child:ListView.separated(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),itemCount:hands[0].length,separatorBuilder:(_,__)=>const SizedBox(width:5),itemBuilder:(ctx,i){final card=hands[0][i];return Draggable<String>(data:card,feedback:Material(color:Colors.transparent,child:Transform.scale(scale:1.12,child:_card(card))),childWhenDragging:Opacity(opacity:.25,child:_card(card)),child:_card(card));})),
      Padding(padding:const EdgeInsets.fromLTRB(10,0,10,10),child:Row(children:[Expanded(child:OutlinedButton(onPressed:_editNames,style:OutlinedButton.styleFrom(foregroundColor:gold,side:const BorderSide(color:gold)),child:const Text('Player names'))),const SizedBox(width:8),Expanded(child:FilledButton(onPressed:_deal,style:FilledButton.styleFrom(backgroundColor:gold,foregroundColor:Colors.black),child:const Text('New round')))])),
    ])),
  );

  Widget _scoreBox(String name,int score)=>Container(padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(11),border:Border.all(color:gold.withOpacity(.65))),child:Column(children:[Text(name,textAlign:TextAlign.center,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white,fontSize:10)),Text('$score',style:const TextStyle(color:gold,fontSize:20,fontWeight:FontWeight.w900))]));
}
