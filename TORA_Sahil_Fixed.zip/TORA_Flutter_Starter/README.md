# TORA Card Game

Current prototype: 52-card deck (13 ranks across four suits), shuffled and dealt as 13 cards to each of four players. Sahil is the local player; Sahil’s 13 cards remain visible while the other three players’ card faces stay hidden. Other player names are placeholders for now.

The full TORA rules, turn engine, scoring, Takol logic, and online multiplayer are not complete yet.
