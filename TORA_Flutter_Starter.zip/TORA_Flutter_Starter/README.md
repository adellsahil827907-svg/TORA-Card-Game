# TORA Flutter Starter

This is the first UI prototype for the TORA card game.

## Important
- The project is a starter prototype, not a finished game or installable APK.
- The current hand is sample UI data only.
- Card dealing, turn validation, full scoring, the exact Takol transfer/pending-transfer rules, online multiplayer, and MANFI are not implemented yet.
- TORA table seating is shown as requested: Matiaullah opposite Mohabbatullah; Zabihullah opposite Mahmood Khan.
- No bid/hand-announcement controls are included in TORA.

## Build
Install Flutter, then run:

```bash
flutter pub get
flutter run
```

To build an Android APK:

```bash
flutter build apk --release
```
